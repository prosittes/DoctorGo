# Kodular Blueprint — DoctorGo

Telas: Splash, Login, SignUp (LGPD com 2 checkboxes obrigatórios), Home_Patient (chips), Doctor_Dashboard, Admin, Payment, Rating.
Regras: mostrar no máximo 3 médicos por cidade+especialidade, ordenar Premium→rating.
Pagamentos: Pix/Débito (taxa R$5 do médico), Cartão (acréscimo ao paciente, médico recebe líquido).
