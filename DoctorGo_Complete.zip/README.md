# DoctorGo — Pacote Completo
Data: 2025-08-31

Inclui GuiaFirebase.md, Exemplos_Firestore.json, LGPD/, Kodular_Blueprint.md.
Siga o GuiaFirebase para criar seu projeto e o Blueprint para montar no Kodular.
