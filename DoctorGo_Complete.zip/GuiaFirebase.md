# Guia Firebase — DoctorGo
Atualizado em 2025-08-31

1) Crie o projeto no console do Firebase.
2) Ative Authentication (email/senha).
3) Crie Firestore Database e cole as regras.
4) Registre app Web e copie as chaves.
5) No Kodular, cole as chaves nos componentes (Auth/Web) e variáveis globais.
